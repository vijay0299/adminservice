package com.nseindia.b2.blogger.models;

import com.nseindia.b2.blogger.entities.Admin;

public class ResponseAdmin {
	
	
	public Admin admin;
//	private int id;
//	private String title;
//	private String body;
//	private String summary;
	private String message;

//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public String getTitle() {
//		return title;
//	}
//
//	public void setTitle(String title) {
//		this.title = title;
//	}
//
//	public String getBody() {
//		return body;
//	}
//
//	public void setBody(String body) {
//		this.body = body;
//	}
//
//	public String getSummary() {
//		return summary;
//	}
//
//	public void setSummary(String summary) {
//		this.summary = summary;
//	}
//
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	

//	@Override
//	public String toString() {
//		return "ResponseAdmin [title=" + title + ", body=" + body + ", summary=" + summary + ", message=" + message
//				+ "]";
//	}

}

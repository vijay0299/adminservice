package com.nseindia.b2.blogger.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nseindia.b2.blogger.entities.Admin;
import com.nseindia.b2.blogger.repositories.Repository;
@Service
public class AdminServiceIMPL implements AdminService {

	@Autowired
	Repository repo;

	@Override
	public List<Admin> getAll() {
		List<Admin> adminList = new ArrayList<Admin>();

		repo.findAll().forEach(a -> {
			adminList.add(a);

		});

		return adminList;

	}

	@Override
	public Admin get(Long id) {
		Admin admin = new Admin();
		admin = repo.findById(id).orElse(null);
		return admin;
	}

	@Override
	public Admin put(Admin admin) {
		admin.setId(null);
		admin = repo.save(admin);

		return admin;
	}

	@Override
	public Admin update(Long id, Admin admin) {
		Admin a = repo.findById(id).orElse(null);

		if (a != null) {
			if (admin.getTitle() != null) {
				a.setTitle(admin.getTitle());
			}
			if(admin.getBody() != null)
			{
				a.setBody(admin.getBody());
			}
			if(admin.getSummary() != null) {
				a.setSummary(admin.getSummary());
			}
			repo.save(a);
			return a;
		}

		return null;
	}

	@Override
	public Admin delete(Long id) {
		Admin admin = repo.findById(id).orElse(null);

		if (admin != null) {
			repo.deleteById(id);
		}
		return admin;
	}

}

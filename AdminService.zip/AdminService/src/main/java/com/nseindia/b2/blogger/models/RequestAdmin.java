package com.nseindia.b2.blogger.models;

import com.nseindia.b2.blogger.entities.Admin;

public class RequestAdmin {

	private String title;
	private String body;
	private String summary;

	public Admin toAdmin() {
		Admin admin = new Admin();
		admin.setTitle(this.title);
		admin.setBody(this.body);
		admin.setSummary(this.summary);
		return admin;
	}
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	@Override
	public String toString() {
		return "RequestAdmin [title=" + title + ", body=" + body + ", summary=" + summary + "]";
	}

}

package com.nseindia.b2.blogger.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nseindia.b2.blogger.entities.Admin;
import com.nseindia.b2.blogger.models.RequestAdmin;
import com.nseindia.b2.blogger.models.ResponseAdmin;
import com.nseindia.b2.blogger.models.ResponseList;
import com.nseindia.b2.blogger.services.AdminService;

@RestController
public class BaseController {

	@Autowired
	AdminService service;

	@GetMapping("/")
	public ResponseList getAll() {
		ResponseList resp = new ResponseList();
		resp.setMessage("List found");
		resp.setAdmin(service.getAll());
		return resp;
	}

	@GetMapping("/{id}")
	public ResponseAdmin get(@PathVariable Long id) {
		ResponseAdmin resp = new ResponseAdmin();
		resp.setAdmin(service.get(id));
		if (resp.admin != null) {
			resp.setMessage("record found successfully");
		} else {
			resp.setMessage("record not found");
		}
		return resp;
	}

	@PostMapping("/")
	public ResponseAdmin put(@RequestBody RequestAdmin request) {
		Admin admin = request.toAdmin();
		admin = service.put(admin);
		ResponseAdmin resp = new ResponseAdmin();
		resp.setAdmin(admin);
		resp.setMessage("Record added");
		return resp;
	}

	@PutMapping("/{id}")
	public ResponseAdmin update(@PathVariable("id") Long id, @RequestBody RequestAdmin request) {
		ResponseAdmin resp = new ResponseAdmin();
		Admin admin = request.toAdmin();
		admin =  service.update(id, admin);
		if(admin != null) {
			resp.setAdmin(admin);
			resp.setMessage("updated");
		}else {
			resp.setMessage("not found");
		}
		return resp;
	}

	@DeleteMapping("/{id}")
	public ResponseAdmin delete(@PathVariable("id") Long id) {
		ResponseAdmin resp = new ResponseAdmin();
		
		Admin admin = service.delete(id);
		if(admin != null) {
			resp.setAdmin(admin);
			resp.setMessage("deleted");
		}else {
			resp.setMessage("not found");
		}
		return resp;
	}

}
